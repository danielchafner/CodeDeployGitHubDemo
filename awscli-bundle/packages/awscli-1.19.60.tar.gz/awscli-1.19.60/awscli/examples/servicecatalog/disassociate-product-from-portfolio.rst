**To disassociate a product from a portfolio**

The following ``disassociate-product-from-portfolio`` example disassociates the specified product from the portfolio. ::

    aws servicecatalog disassociate-product-from-portfolio \
        --product-id prod-3p5abcdmu3oyk \
        --portfolio-id port-2s6abcdq5wdh4

This command produces no output.
