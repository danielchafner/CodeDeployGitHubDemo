**To delete a document**

This example deletes the specified document.

Command::

  aws workdocs delete-document --document-id b83ed5e5b167b65ef69de9d597627ff1a0d4f07a45e67f1fab7d26b54427de0a

Output::

  None